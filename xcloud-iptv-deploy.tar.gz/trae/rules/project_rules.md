KW primárias: xcloud iptv
Concorrentes: https://xcloudtv.com.br/, https://xcloudtv.app/ (fazer ANALISE DE benchmark, análise seo)
Páginas previstas: home, teste gratis, planos, contato, sobre nós
Objetivo de negócio: captar assinaturas e leads para Xcloud IPTV, uma plataforma de streaming que oferece uma variedade de conteúdo, incluindo filmes, séries, documentários e muito mais.
Marca: Xcloud IPTV
Logo: "anexos\logo_app_xcloudtv.png"
cores: use as cores baseadas na logo;
Persona/região: Brasil, interessados em “Xcloud IPTV” (aplicativo de iptv)
Url: xcloudiptv.com.br

➡️ OS Planos São:
Planos:
01 Mês R$ 30,00 > https://pay.cakto.com.br/f2h6gau
03 Meses DE R$81,00 > https://pay.cakto.com.br/42n8kgr
06 Meses R$ 153,00 > https://pay.cakto.com.br/3bndnkh
12 Meses R$ 288,00 > https://pay.cakto.com.br/3crawid
USe os links para redirecionar ao metodo de pagamento no cakto.


Na geração do teste, precisamos de informações de Nome, email e telefone do cliente e leads; Esse formulário estará ligado a um webhook externo que irá receber os dados e enviar para o nosso sistema de geração de testes;
O site precisa ser responsivo para bom funcionamento em diferentes telas;
Sempre manter robots e sitemap atualizados;
Não use nomes de filmes, séries ou canais no site;
Mantenha um padrão de layout e design consistente em todo o site.
Não iremos expor nosso número de telefone no site;
Suporte será feito via email;
Garanta textos e botões com cores contrastantes para melhor usabilidade;
Suporte via whatsapp exclusivo para clientes, então não será exposto no site;
horário de atendimento é: Segunda a sábado: 9h às 22h;
A duração dos testes são de "Até 6 horas de duração", não coloque nada dizendo que o teste é de 6 horas!;

Considere relevante a analise do concorrente, pois se ele está em primeiro nas buscas ele é pq o google entende a relevancia dele no assunto. Então se o google considerda relevante tbm devos considerar e ter como exemplo na criação do site.
Todas as paginas devem ter seo otimizado:
Pagina home deve ter conteúdo otimizado conteúdo headlines dos concorrentes, otimizadas para posicionamento para as palavras chaves definidas acima! Lembre-se de usar as palavras chaves de forma natural e contextualizada no conteúdo, o texto deve ser rico em conteúdo!
Pagina Planos: Deve ser otimizada para palavras chaves: planos xcloud iptv, assinar xcloud iptv
Pagina de teste grátis: otimizada para palavras chaves: teste gratis xcloud iptv, teste iptv xcloud;
não quero que dê ênfase a qualidade nenhuma de imagem;


### PADRÕES DE CONSISTÊNCIA Elementos que devem ser replicados:
1. Cores : Sempre usar o verde #22c55e como primário
2. Glass cards : Background semi-transparente com blur
3. Gradientes : Verde para preto em todos os elementos principais
4. Animações : Transições suaves de 300ms
5. Bordas : Arredondamento consistente (xl, 2xl, 3xl)
6. Sombreamento : Sombras profundas para dar profundidade
7. Tipografia : Hierarquia clara com tamanhos proporcionais
8. Espaçamentos : Sistema consistente de gaps e paddings
9. Efeitos de hover : Scale e mudanças de cor suaves
10. Background : Sempre escuro com elementos de brilho sutil

é possivel instalar o xcloud tv em: android tv, celular android, ios, fire stick  (via downloader), mi stick (via downloader), windows, smart tvs lg, samsung e roku.
se for necessário, para instruções de instalação instrua a busca por "XcloudTV" e não "Xcloud IPTV".
