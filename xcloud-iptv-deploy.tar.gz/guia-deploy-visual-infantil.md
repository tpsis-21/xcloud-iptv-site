# 🎯 Guia Visual: Publicar Seu Site (Tipo Montar Lego!)

## 🧱 O que é Cada Coisa? (Explicação de Vovó)

| Termo Técnico | O que é na Vida Real | Anologia |
|---------------|---------------------|----------|
| **VPS** | Seu computador na nuvem | É como ter um PC lá longe que fica ligado 24h |
| **EasyPanel** | Painel de controle | É tipo o "Painel de Controle" do Windows, mas pros sites |
| **Docker** | Caixinha mágica | Empacota seu site numa caixinha que funciona em qualquer lugar |
| **SSL** | Cadeado verde | Deixa seu site seguro (tipo fechadura na porta) |
| **Cloudflare** | Segurança + Turbo | É tipo um segurança que também deixa seu site mais rápido |

---

## 🎮 Passo 1: Entrar no EasyPanel (Como Entrar no Facebook)

### 📱 Tela por Tela:

```
1. Abra seu navegador (Chrome, Firefox, etc)
2. Digite na barra de endereços: http://123.45.67.89:3000
   ┌─────────────────────────────────────┐
   │ 🌐 Barra de endereços do navegador  │
   ├─────────────────────────────────────┤
   │ http://123.45.67.89:3000           │
   └─────────────────────────────────────┘
3. Digite seu login e senha
4. Clique em "Entrar"
```

> 🎯 **Onde pegar o IP?** Seu provedor de VPS te enviou por email!

---

## 🏠 Passo 2: Criar Casa para Seu Site

### 🏡 Analogy: É como montar uma casa!

```
EasyPanel → Novo Projeto → Preencher:
┌─────────────────────────────────────────┐
│ 📋 FORMULÁRIO DE NOVO PROJETO         │
├─────────────────────────────────────────┤
│ Nome: xcloud-iptv                    │
│ Descrição: Meu site de IPTV          │
│ [CRIAR PROJETO] ← Clique aqui!       │
└─────────────────────────────────────────┘
```

---

## 📦 Passo 3: Colocar Site Dentro da Caixa

### Copiar e Colar Mágico:

```yaml
# 📝 COPIE ISTO TUDO (Ctrl+C)
version: '3.8'
services:
  xcloud-site:
    image: node:18-alpine
    working_dir: /app
    volumes:
      - ./site:/app
    ports:
      - "3001:3000"
    command: >
      sh -c "
        npm install &&
        npm run build &&
        npm start
      "
    restart: unless-stopped
    environment:
      - NODE_ENV=production
```

```
# 📍 COLAR NO EASY PANEL:
EasyPanel → Adicionar Serviço → Docker Compose
┌─────────────────────────────────────────┐
│ 🖥️  ÁREA PARA COLAR O CÓDIGO           │
│                                         │
│ [COLE AQUI ↑]                          │
│                                         │
│ [SALVAR] ← Clique!                    │
└─────────────────────────────────────────┘
```

---

## 📤 Passo 4: Enviar Seu Site (Como Mandar Foto no WhatsApp)

### Opção 1: Método "Arrastar para o WhatsApp"

```bash
# 💻 NO SEU COMPUTADOR (PowerShell/CMD)
# Entrar na pasta do site primeiro
cd C:\Users\SeuNome\Documents\SITE XCLOUDTV

# Mandar tudo pro servidor
scp -r . root@123.45.67.89:/root/xcloud-iptv/site/

# ↑ ↑ ↑ ↑ ↑ ↑ ↑ ↑ ↑ ↑ ↑ ↑ ↑ ↑ ↑ ↑ ↑ ↑ ↑ ↑ ↑ ↑ ↑ ↑
# | | | | | | | | | | | | | | | | | | | | | | | |
# Seu IP vai aqui ↑
```

### Opção 2: Método "Git" (Mais Profissional)

```bash
# 1️⃣ Primeiro: Preparar as malas
git init
git add .
git commit -m "Primeira versão do site"

# 2️⃣ Segundo: Mandar pro servidor
git remote add production root@123.45.67.89:/root/xcloud-iptv/site
git push production master
```

---

## 🔒 Passo 5: Ativar o Cadeado Verde (SSL)

### 🟢 Como Ativar:

```
EasyPanel → Configurações → SSL/TLS
┌─────────────────────────────────────────┐
│ 🔐 CONFIGURAÇÃO SSL                    │
├─────────────────────────────────────────┤
│ Domínio: [xcloudiptv.com.br]          │
│                                         │
│ [GERAR CERTIFICADO SSL] ← Clique!     │
│                                         │
│ Status: ⏳ Aguardando...              │
│ Status: ✅ Ativado!                    │
└─────────────────────────────────────────┘
```

> ⏰ **Tempo de espera:** 2-3 minutinhos

---

## ☁️ Passo 6: Cloudflare (Turbo + Segurança)

### 🌪️ Como Configurar:

```
Passo 1: Cloudflare.com → "Add Site"
┌─────────────────────────────────────────┐
│ 🌐 CLOUDFLARE - ADICIONAR SITE         │
├─────────────────────────────────────────┤
│ Digite seu domínio:                    │
│ [xcloudiptv.com.br]                    │
│                                         │
│ [CONTINUAR] ← Clique!                  │
└─────────────────────────────────────────┘

Passo 2: Escolher Plano
┌─────────────────────────────────────────┐
│ 💰 ESCOLHER PLANO                      │
├─────────────────────────────────────────┤
│ ○ Free (Grátis) ← MARQUE ESTE!        │
│ ○ Pro                                    │
│ ○ Business                               │
│                                         │
│ [CONTINUAR]                             │
└─────────────────────────────────────────┘
```

### 📝 Configuração DNS (Muito Importante!)

```
Cloudflare → DNS
┌─────────────────────────────────────────┐
│ 📝 REGISTROS DNS                       │
├─────────────────────────────────────────┤
│ Type: A                                 │
│ Name: @                                  │
│ IPv4: 123.45.67.89  ← Seu IP          │
│ Proxy: ☁️ (Nuvem laranja ATIVADA)     │
│                                         │
│ Type: A                                 │
│ Name: www                               │
│ IPv4: 123.45.67.89  ← Seu IP          │
│ Proxy: ☁️ (Nuvem laranja ATIVADA)     │
└─────────────────────────────────────────┘
```

---

## 🧪 TESTE FINAL: Checklist de Sucesso

### ✅ Se Tudo Estiver Certo:

```
🔍 TESTE 1: Digitar xcloudiptv.com.br
   Resultado: ✓ Site abre!

🔍 TESTE 2: Digitar https://xcloudiptv.com.br  
   Resultado: ✓ Cadeado verde aparece!

🔍 TESTE 3: Preencher formulário de teste
   Resultado: ✓ Dados vão pro webhook!

🔍 TESTE 4: Testar velocidade
   Resultado: ✓ Site carrega rápido!
```

---

## 🚨 SOS - Problemas Comuns

### 😱 "Meu site não abre!"

**Solução Baby Steps:**
```bash
# 1. Verificar se está ligado
docker ps

# 2. Se não estiver, ligar
docker-compose up -d

# 3. Verificar erros
docker logs xcloud-site
```

### 😱 "Cadeado verde não aparece!"

**Solução:**
```bash
# Esperar 5 minutos e tentar novamente
# Se não funcionar, gerar novo certificado
certbot certonly --webroot -w /var/www/html -d xcloudiptv.com.br
```

### 😱 "Formulário não funciona!"

**Solução:**
```bash
# Verificar se webhook está correto
docker logs xcloud-site | grep webhook
```

---

## 🎉 PARABÉNS! Você Conseguiu!

### 🏆 Conquistas Desbloqueadas:
- ✅ Site online 24h por dia
- ✅ Segurança SSL ativada  
- ✅ Proteção Cloudflare
- ✅ Formulário funcionando
- ✅ Pronto para clientes!

### 🎁 Bônus: O que fazer agora?
1. Mande o link para 3 amigos testarem
2. Poste nas redes sociais
3. Comece a vender suas assinaturas!

---

## 📞 Precisando de Ajuda?

### Manda mensagem com:
```
"Oi! Meu site xcloudiptv.com.br está com problema:
- O que acontece: [descreva o erro]
- O que eu fiz: [última coisa que fez]
- Print do erro: [se possível]"
```

**Vamos resolver juntos!** 🚀